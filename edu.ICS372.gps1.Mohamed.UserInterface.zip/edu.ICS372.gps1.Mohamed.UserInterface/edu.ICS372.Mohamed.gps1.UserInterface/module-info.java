/**
 * 
 */
/**
 * @author Abshir Mohamed
 *
 */
module edu.ICS372.gps1.Mohamed.UserInterface {
	requires edu.ICS372.gps1.Mohamed.Store.Business;
}